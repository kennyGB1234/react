import React from 'react'

const Contacto = () => {
  return (
    <div>
      <h2>Contacto</h2>
      <p><a href="mailto:elcorreoquequieres@correo.com">Enviar correo</a></p>
     <p><a href="tel:+34678567876">Realizar llamada</a></p>
    </div>
  )
}

export default Contacto
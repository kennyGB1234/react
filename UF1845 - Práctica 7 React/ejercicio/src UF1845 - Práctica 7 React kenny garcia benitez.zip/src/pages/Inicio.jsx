import React from 'react'

const Inicio = () => {
  return (
    <div>
      <h1>Bienvenido al formulario</h1>
      <div className='qqq'>
    
      </div>
      </div>
  )
}

export default Inicio
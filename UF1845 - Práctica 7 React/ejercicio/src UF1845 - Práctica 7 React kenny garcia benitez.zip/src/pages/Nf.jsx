import React from 'react'

const Nf = () => {
  return (
    <div>
      <h1>
        Nf 
      </h1>
      <br />
      <h1>
        Error 404 !!
      </h1>
     
      </div>
  )
}

export default Nf
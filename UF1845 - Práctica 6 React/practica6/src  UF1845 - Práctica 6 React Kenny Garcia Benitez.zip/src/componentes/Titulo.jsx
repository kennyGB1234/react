import React from 'react';

const Titulo = () => {
	return (
		<div className='all-center'>
			<h1>Zapatos 'El Ñoño'</h1>
		</div>
	);
};

export default Titulo;


import './App.css';
import Blog from './Components/Blog';
import Pruebas from './Components/Pruebas';


function App() {
  return (
    <div className='contenedor'>
      <div className='uno'>
        <Blog />
      </div>
    <div className='dos'>
      <Pruebas/>
    </div>
    
    </div>
  );
}

export default App;
